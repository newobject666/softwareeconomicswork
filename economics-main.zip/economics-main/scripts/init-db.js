const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');

async function initDatabase() {
  try {
    console.log('🔄 Connexion à la base de données Railway...');
    
    let connection;
    
    if (process.env.MYSQL_URL) {
      console.log('📡 Utilisation de MYSQL_URL');
      connection = await mysql.createConnection(process.env.MYSQL_URL);
    } else if (process.env.MYSQL_HOST) {
      console.log('📡 Utilisation des paramètres individuels');
      connection = await mysql.createConnection({
        host: process.env.MYSQL_HOST,
        user: process.env.MYSQL_USER,
        password: process.env.MYSQL_PASSWORD,
        database: process.env.MYSQL_DATABASE,
        port: parseInt(process.env.MYSQL_PORT || '3306')
      });
    } else {
      throw new Error('Aucune configuration MySQL trouvée');
    }

    console.log('✅ Connecté à Railway MySQL');

    // Lire le schéma SQL
    const schemaPath = path.join(__dirname, '../database/schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    
    // Nettoyer et séparer les instructions SQL
    const statements = schema
      .split(';')
      .map(stmt => stmt.trim())
      .filter(stmt => stmt && 
        !stmt.startsWith('CREATE DATABASE') && 
        !stmt.startsWith('USE')
      );

    console.log(`📝 Exécution de ${statements.length} instructions SQL...`);

    // Exécuter chaque instruction
    for (const statement of statements) {
      if (statement) {
        try {
          await connection.execute(statement);
          const tableName = statement.match(/CREATE TABLE.*?`?(\w+)`?/i)?.[1] || 'unknown';
          console.log(`✅ Table créée: ${tableName}`);
        } catch (error) {
          if (!error.message.includes('already exists')) {
            console.error(`❌ Erreur SQL:`, error.message);
          } else {
            const tableName = statement.match(/CREATE TABLE.*?`?(\w+)`?/i)?.[1] || 'unknown';
            console.log(`ℹ️  Table existe déjà: ${tableName}`);
          }
        }
      }
    }

    await connection.end();
    console.log('🎉 Base de données initialisée avec succès!');
    
  } catch (error) {
    console.error('❌ Erreur de connexion:', error.message);
    console.error('Variables disponibles:');
    console.error('- MYSQL_URL:', process.env.MYSQL_URL ? 'Définie' : 'Non définie');
    console.error('- MYSQL_HOST:', process.env.MYSQL_HOST || 'Non définie');
    console.error('- MYSQL_USER:', process.env.MYSQL_USER || 'Non définie');
    console.error('- MYSQL_DATABASE:', process.env.MYSQL_DATABASE || 'Non définie');
    process.exit(1);
  }
}

initDatabase();