CREATE DATABASE IF NOT EXISTS economics_tool;
USE economics_tool;

CREATE TABLE IF NOT EXISTS projects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  -- Cost Estimation Data
  cocomo_kloc DECIMAL(10,2),
  cocomo_project_type ENUM('organic', 'semi-detached', 'embedded'),
  cocomo_effort DECIMAL(10,2),
  cocomo_time DECIMAL(10,2),
  cocomo_people DECIMAL(10,2),
  
  fp_inputs INT,
  fp_outputs INT,
  fp_inquiries INT,
  fp_files INT,
  fp_interfaces INT,
  fp_complexity ENUM('simple', 'average', 'complex'),
  fp_adjusted_fp DECIMAL(10,2),
  
  -- Budgeting Data
  initial_investment DECIMAL(15,2),
  annual_cash_flows JSON,
  discount_rate DECIMAL(5,4),
  roi DECIMAL(10,4),
  npv DECIMAL(15,2),
  irr DECIMAL(10,4),
  payback_period DECIMAL(10,2),
  
  -- Risk Management Data
  sensitivity_analysis JSON,
  monte_carlo_results JSON,
  risk_register JSON,
  
  -- Resource Allocation Data
  resources JSON,
  tasks JSON,
  schedule JSON
);

CREATE TABLE IF NOT EXISTS risk_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  project_id INT,
  description TEXT NOT NULL,
  probability DECIMAL(3,2),
  impact DECIMAL(3,2),
  risk_score DECIMAL(5,2),
  mitigation TEXT,
  status ENUM('open', 'mitigated', 'closed') DEFAULT 'open',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS resources (
  id INT AUTO_INCREMENT PRIMARY KEY,
  project_id INT,
  name VARCHAR(255) NOT NULL,
  type ENUM('developer', 'designer', 'tester', 'manager'),
  hourly_rate DECIMAL(8,2),
  availability DECIMAL(3,2),
  skills JSON,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS tasks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  project_id INT,
  name VARCHAR(255) NOT NULL,
  duration INT,
  required_skills JSON,
  priority INT,
  dependencies JSON,
  resource_requirement INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);