'use client';

import { useState } from 'react';
import Link from 'next/link';

interface FinancialInputs {
  initialInvestment: number;
  annualCashFlows: number[];
  discountRate: number;
  projectDuration: number;
}

export default function Budgeting() {
  const [activeTab, setActiveTab] = useState('roi-npv');
  const [inputs, setInputs] = useState<FinancialInputs>({
    initialInvestment: 100000,
    annualCashFlows: [30000, 40000, 50000, 60000, 70000],
    discountRate: 10,
    projectDuration: 5
  });

  // Financial calculations
  const calculateROI = () => {
    const totalCashFlows = inputs.annualCashFlows.reduce((sum, flow) => sum + flow, 0);
    const roi = ((totalCashFlows - inputs.initialInvestment) / inputs.initialInvestment) * 100;
    return roi;
  };

  const calculateNPV = () => {
    const discountRate = inputs.discountRate / 100;
    let npv = -inputs.initialInvestment;
    
    inputs.annualCashFlows.forEach((cashFlow, index) => {
      npv += cashFlow / Math.pow(1 + discountRate, index + 1);
    });
    
    return npv;
  };

  const calculateIRR = () => {
    let irr = 0.1;
    const tolerance = 0.0001;
    const maxIterations = 100;
    
    for (let i = 0; i < maxIterations; i++) {
      let npv = -inputs.initialInvestment;
      let derivative = 0;
      
      inputs.annualCashFlows.forEach((cashFlow, index) => {
        const period = index + 1;
        npv += cashFlow / Math.pow(1 + irr, period);
        derivative -= (period * cashFlow) / Math.pow(1 + irr, period + 1);
      });
      
      if (Math.abs(npv) < tolerance) break;
      irr = irr - npv / derivative;
    }
    
    return irr * 100;
  };

  const calculatePaybackPeriod = () => {
    let cumulativeCashFlow = -inputs.initialInvestment;
    
    for (let i = 0; i < inputs.annualCashFlows.length; i++) {
      cumulativeCashFlow += inputs.annualCashFlows[i];
      if (cumulativeCashFlow >= 0) {
        const previousCumulative = cumulativeCashFlow - inputs.annualCashFlows[i];
        const fraction = Math.abs(previousCumulative) / inputs.annualCashFlows[i];
        return i + fraction;
      }
    }
    return inputs.annualCashFlows.length;
  };

  const updateCashFlow = (index: number, value: number) => {
    const newCashFlows = [...inputs.annualCashFlows];
    newCashFlows[index] = value;
    setInputs({ ...inputs, annualCashFlows: newCashFlows });
  };

  const addYear = () => {
    setInputs({
      ...inputs,
      annualCashFlows: [...inputs.annualCashFlows, 0],
      projectDuration: inputs.projectDuration + 1
    });
  };

  const removeYear = () => {
    if (inputs.annualCashFlows.length > 1) {
      setInputs({
        ...inputs,
        annualCashFlows: inputs.annualCashFlows.slice(0, -1),
        projectDuration: inputs.projectDuration - 1
      });
    }
  };

  const tabs = [
    { id: 'roi-npv', label: 'ROI & NPV', icon: '💰' }
  ];

  const roi = calculateROI();
  const npv = calculateNPV();
  const irr = calculateIRR();
  const paybackPeriod = calculatePaybackPeriod();

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <Link href="/" className="inline-flex items-center px-4 py-2 bg-white/80 backdrop-blur-sm border border-gray-200 rounded-xl text-gray-700 hover:bg-gray-50 transition-all duration-200 shadow-sm hover:shadow-md">
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
                Back to Home
              </Link>
            </div>
          </div>
          
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-500 rounded-2xl mb-6 shadow-lg">
              <span className="text-white text-2xl">📊</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Budget & Cost Management</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Analyze financial performance with ROI, NPV, IRR calculations and cash flow management
            </p>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex justify-center mb-8">
          <div className="inline-flex bg-white/80 backdrop-blur-sm rounded-2xl p-2 shadow-lg border border-gray-200/50">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-6 py-3 rounded-xl font-medium transition-all duration-200 ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white shadow-md'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                }`}
              >
                <span className="text-lg">{tab.icon}</span>
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="max-w-6xl mx-auto">
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl border border-gray-200/50 overflow-hidden">
            {activeTab === 'roi-npv' && (
              <div className="p-8 animate-fadeIn">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Inputs */}
                  <div className="space-y-6">
                    <div className="flex items-center space-x-3 mb-6">
                      <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center">
                        <span className="text-white text-lg">⚙️</span>
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-900">Financial Parameters</h3>
                        <p className="text-gray-600 text-sm">Configure your project finances</p>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Initial Investment ($)
                        </label>
                        <input
                          type="number"
                          value={inputs.initialInvestment}
                          onChange={(e) => setInputs({ ...inputs, initialInvestment: parseFloat(e.target.value) || 0 })}
                          className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
                          placeholder="Enter initial investment"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Discount Rate (%)
                        </label>
                        <input
                          type="number"
                          step="0.1"
                          value={inputs.discountRate}
                          onChange={(e) => setInputs({ ...inputs, discountRate: parseFloat(e.target.value) || 0 })}
                          className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
                          placeholder="Enter discount rate"
                        />
                      </div>
                      
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <label className="block text-sm font-medium text-gray-700">
                            Annual Cash Flows ($)
                          </label>
                          <div className="flex space-x-2">
                            <button
                              onClick={addYear}
                              className="px-3 py-1 bg-green-500 text-white text-xs rounded-lg hover:bg-green-600 transition-colors"
                            >
                              + Year
                            </button>
                            <button
                              onClick={removeYear}
                              className="px-3 py-1 bg-red-500 text-white text-xs rounded-lg hover:bg-red-600 transition-colors"
                              disabled={inputs.annualCashFlows.length <= 1}
                            >
                              - Year
                            </button>
                          </div>
                        </div>
                        <div className="space-y-2">
                          {inputs.annualCashFlows.map((cashFlow, index) => (
                            <div key={index} className="flex items-center space-x-2">
                              <span className="text-sm font-medium text-gray-600 w-16">Year {index + 1}:</span>
                              <input
                                type="number"
                                value={cashFlow}
                                onChange={(e) => updateCashFlow(index, parseFloat(e.target.value) || 0)}
                                className="flex-1 px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
                                placeholder="Cash flow"
                              />
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Results */}
                  <div className="space-y-6">
                    <div className="flex items-center space-x-3 mb-6">
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-xl flex items-center justify-center">
                        <span className="text-white text-lg">📊</span>
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-900">Financial Analysis</h3>
                        <p className="text-gray-600 text-sm">Calculated metrics</p>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      {/* ROI */}
                      <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-6 border border-green-200/50">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="text-lg font-bold text-gray-900">Return on Investment</h4>
                          <span className="text-2xl">💰</span>
                        </div>
                        <div className="text-3xl font-bold text-green-600 mb-2">
                          {roi.toFixed(1)}%
                        </div>
                        <div className="text-sm text-gray-600 mb-4">
                          Total return on your investment
                        </div>
                        <div className={`text-sm font-medium ${
                          roi > 20 ? 'text-green-600' : 
                          roi > 10 ? 'text-yellow-600' : 'text-red-600'
                        }`}>
                          {roi > 20 ? '✓ Excellent return' : 
                           roi > 10 ? '⚠ Good return' : '✗ Low return'}
                        </div>
                      </div>

                      {/* NPV */}
                      <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl p-6 border border-blue-200/50">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="text-lg font-bold text-gray-900">Net Present Value</h4>
                          <span className="text-2xl">📈</span>
                        </div>
                        <div className={`text-3xl font-bold mb-2 ${
                          npv > 0 ? 'text-green-600' : 'text-red-600'
                        }`}>
                          ${npv.toLocaleString()}
                        </div>
                        <div className="text-sm text-gray-600 mb-4">
                          Present value of future cash flows
                        </div>
                        <div className={`text-sm font-medium ${
                          npv > 0 ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {npv > 0 ? '✓ Positive NPV - Accept project' : '✗ Negative NPV - Reject project'}
                        </div>
                      </div>

                      {/* IRR */}
                      <div className="bg-gradient-to-br from-orange-50 to-red-50 rounded-2xl p-6 border border-orange-200/50">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="text-lg font-bold text-gray-900">Internal Rate of Return</h4>
                          <span className="text-2xl">🎯</span>
                        </div>
                        <div className="text-3xl font-bold text-orange-600 mb-2">
                          {irr.toFixed(1)}%
                        </div>
                        <div className="text-sm text-gray-600 mb-4">
                          Rate that makes NPV equal to zero
                        </div>
                        <div className={`text-sm font-medium ${
                          irr > inputs.discountRate ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {irr > inputs.discountRate ? '✓ IRR > Discount Rate' : '✗ IRR < Discount Rate'}
                        </div>
                      </div>

                      {/* Payback Period */}
                      <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-6 border border-purple-200/50">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="text-lg font-bold text-gray-900">Payback Period</h4>
                          <span className="text-2xl">⏰</span>
                        </div>
                        <div className="text-3xl font-bold text-purple-600 mb-2">
                          {paybackPeriod.toFixed(1)} years
                        </div>
                        <div className="text-sm text-gray-600 mb-4">
                          Time needed to recover the investment
                        </div>
                        <div className={`text-sm font-medium ${
                          paybackPeriod <= 3 ? 'text-green-600' : 
                          paybackPeriod <= 5 ? 'text-yellow-600' : 'text-red-600'
                        }`}>
                          {paybackPeriod <= 3 ? '✓ Fast recovery' : 
                           paybackPeriod <= 5 ? '⚠ Moderate recovery' : '✗ Slow recovery'}
                        </div>
                      </div>
                    </div>

                    {/* Comparative Analysis */}
                    <div className="bg-gradient-to-br from-gray-50 to-blue-50 rounded-2xl p-6 border border-gray-200/50">
                      <h4 className="text-xl font-bold text-gray-900 mb-6">Comparative Analysis</h4>
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div className="text-center p-4 bg-white rounded-xl">
                          <div className="text-2xl font-bold text-green-600">{roi.toFixed(1)}%</div>
                          <div className="text-sm text-gray-600">ROI</div>
                        </div>
                        <div className="text-center p-4 bg-white rounded-xl">
                          <div className="text-2xl font-bold text-blue-600">${npv.toLocaleString()}</div>
                          <div className="text-sm text-gray-600">NPV</div>
                        </div>
                        <div className="text-center p-4 bg-white rounded-xl">
                          <div className="text-2xl font-bold text-orange-600">{irr.toFixed(1)}%</div>
                          <div className="text-sm text-gray-600">IRR</div>
                        </div>
                        <div className="text-center p-4 bg-white rounded-xl">
                          <div className="text-2xl font-bold text-purple-600">{paybackPeriod.toFixed(1)}</div>
                          <div className="text-sm text-gray-600">Years</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}