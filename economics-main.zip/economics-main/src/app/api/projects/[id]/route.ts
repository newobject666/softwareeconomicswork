import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/mysql';
import { ProjectData } from '@/lib/models';
import { RowDataPacket, ResultSetHeader } from 'mysql2';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const [rows] = await pool.execute<RowDataPacket[]>(
      'SELECT * FROM projects WHERE id = ?',
      [params.id]
    );
    
    if (rows.length === 0) {
      return NextResponse.json({ error: 'Project not found' }, { status: 404 });
    }
    
    const project = rows[0] as ProjectData;
    
    // Parse JSON fields
    if (project.budgeting?.annualCashFlows) {
      project.budgeting.annualCashFlows = JSON.parse(project.budgeting.annualCashFlows as any);
    }
    
    return NextResponse.json({ project });
  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json({ error: 'Failed to fetch project' }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const updateData: Partial<ProjectData> = await request.json();
    
    // Build dynamic SQL update query
    const fields = [];
    const values = [];
    
    if (updateData.name) {
      fields.push('name = ?');
      values.push(updateData.name);
    }
    
    if (updateData.description) {
      fields.push('description = ?');
      values.push(updateData.description);
    }
    
    if (updateData.costEstimation?.cocomo) {
      const cocomo = updateData.costEstimation.cocomo;
      fields.push('cocomo_kloc = ?', 'cocomo_project_type = ?', 'cocomo_effort = ?', 'cocomo_time = ?', 'cocomo_people = ?');
      values.push(cocomo.kloc, cocomo.projectType, cocomo.effort, cocomo.time, cocomo.people);
    }
    
    if (updateData.budgeting) {
      const budgeting = updateData.budgeting;
      fields.push('initial_investment = ?', 'annual_cash_flows = ?', 'discount_rate = ?', 'roi = ?', 'npv = ?', 'irr = ?', 'payback_period = ?');
      values.push(
        budgeting.initialInvestment,
        JSON.stringify(budgeting.annualCashFlows),
        budgeting.discountRate,
        budgeting.roi,
        budgeting.npv,
        budgeting.irr,
        budgeting.paybackPeriod
      );
    }
    
    fields.push('updated_at = NOW()');
    values.push(params.id);
    
    const [result] = await pool.execute<ResultSetHeader>(
      `UPDATE projects SET ${fields.join(', ')} WHERE id = ?`,
      values
    );
    
    if (result.affectedRows === 0) {
      return NextResponse.json({ error: 'Project not found' }, { status: 404 });
    }
    
    return NextResponse.json({ message: 'Project updated successfully' });
  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json({ error: 'Failed to update project' }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const [result] = await pool.execute<ResultSetHeader>(
      'DELETE FROM projects WHERE id = ?',
      [params.id]
    );
    
    if (result.affectedRows === 0) {
      return NextResponse.json({ error: 'Project not found' }, { status: 404 });
    }
    
    return NextResponse.json({ message: 'Project deleted successfully' });
  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json({ error: 'Failed to delete project' }, { status: 500 });
  }
}