'use client';

import { useState } from 'react';
import Link from 'next/link';

interface Resource {
  id: string;
  name: string;
  type: 'developer' | 'designer' | 'tester' | 'manager';
  hourlyRate: number;
  availability: number;
  skills: string[];
}

interface Task {
  id: string;
  name: string;
  duration: number;
  requiredSkills: string[];
  priority: number;
  dependencies: string[];
  resourceRequirement: number;
}

interface Scenario {
  name: string;
  budget: number;
  timeline: number;
  qualityWeight: number;
  costWeight: number;
  timeWeight: number;
}

export default function ResourceAllocation() {
  const [activeTab, setActiveTab] = useState('data-input');
  const [resources, setResources] = useState<Resource[]>([
    { id: '1', name: 'John Doe', type: 'developer', hourlyRate: 75, availability: 8, skills: ['React', 'Node.js', 'TypeScript'] },
    { id: '2', name: 'Jane Smith', type: 'designer', hourlyRate: 65, availability: 8, skills: ['UI/UX', 'Figma', 'Prototyping'] },
    { id: '3', name: 'Bob Johnson', type: 'tester', hourlyRate: 55, availability: 8, skills: ['Automation', 'Manual Testing', 'Selenium'] },
    { id: '4', name: 'Alice Brown', type: 'manager', hourlyRate: 95, availability: 8, skills: ['Project Management', 'Agile', 'Leadership'] }
  ]);
  
  const [tasks, setTasks] = useState<Task[]>([
    { id: 't1', name: 'Frontend Development', duration: 15, requiredSkills: ['React', 'TypeScript'], priority: 1, dependencies: [], resourceRequirement: 120 },
    { id: 't2', name: 'Backend API', duration: 12, requiredSkills: ['Node.js', 'TypeScript'], priority: 1, dependencies: [], resourceRequirement: 96 },
    { id: 't3', name: 'UI Design', duration: 8, requiredSkills: ['UI/UX', 'Figma'], priority: 2, dependencies: [], resourceRequirement: 64 },
    { id: 't4', name: 'Testing', duration: 10, requiredSkills: ['Automation', 'Manual Testing'], priority: 3, dependencies: ['t1', 't2'], resourceRequirement: 80 },
    { id: 't5', name: 'Project Management', duration: 20, requiredSkills: ['Project Management'], priority: 1, dependencies: [], resourceRequirement: 160 }
  ]);

  const [scenarios] = useState<Scenario[]>([
    { name: 'Fast', budget: 150000, timeline: 30, qualityWeight: 0.2, costWeight: 0.3, timeWeight: 0.5 },
    { name: 'Balanced', budget: 120000, timeline: 45, qualityWeight: 0.33, costWeight: 0.33, timeWeight: 0.34 },
    { name: 'Economic', budget: 80000, timeline: 60, qualityWeight: 0.5, costWeight: 0.4, timeWeight: 0.1 }
  ]);

  // Form states
  const [newResource, setNewResource] = useState({
    name: '',
    type: 'developer' as Resource['type'],
    hourlyRate: 0,
    availability: 8,
    skills: ''
  });

  const [newTask, setNewTask] = useState({
    name: '',
    duration: 0,
    requiredSkills: '',
    priority: 1,
    dependencies: '',
    resourceRequirement: 0
  });

  const getResourceTypeIcon = (type: string) => {
    const icons = {
      developer: '👨‍💻',
      designer: '🎨',
      tester: '🧪',
      manager: '👔'
    };
    return icons[type as keyof typeof icons] || '👤';
  };

  const getResourceTypeColor = (type: string) => {
    const colors = {
      developer: 'from-blue-500 to-cyan-500',
      designer: 'from-pink-500 to-purple-500',
      tester: 'from-green-500 to-teal-500',
      manager: 'from-orange-500 to-red-500'
    };
    return colors[type as keyof typeof colors] || 'from-gray-500 to-gray-600';
  };

  const getPriorityColor = (priority: number) => {
    switch (priority) {
      case 1: return 'bg-red-100 text-red-700 border-red-200';
      case 2: return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 3: return 'bg-green-100 text-green-700 border-green-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const addResource = () => {
    if (newResource.name && newResource.hourlyRate > 0) {
      const resource: Resource = {
        id: Date.now().toString(),
        name: newResource.name,
        type: newResource.type,
        hourlyRate: newResource.hourlyRate,
        availability: newResource.availability,
        skills: newResource.skills.split(',').map(s => s.trim()).filter(s => s)
      };
      setResources([...resources, resource]);
      setNewResource({ name: '', type: 'developer', hourlyRate: 0, availability: 8, skills: '' });
    }
  };

  const addTask = () => {
    if (newTask.name && newTask.duration > 0) {
      const task: Task = {
        id: Date.now().toString(),
        name: newTask.name,
        duration: newTask.duration,
        requiredSkills: newTask.requiredSkills.split(',').map(s => s.trim()).filter(s => s),
        priority: newTask.priority,
        dependencies: newTask.dependencies.split(',').map(s => s.trim()).filter(s => s),
        resourceRequirement: newTask.resourceRequirement
      };
      setTasks([...tasks, task]);
      setNewTask({ name: '', duration: 0, requiredSkills: '', priority: 1, dependencies: '', resourceRequirement: 0 });
    }
  };

  const removeResource = (id: string) => {
    setResources(resources.filter(r => r.id !== id));
  };

  const removeTask = (id: string) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  const calculateOptimalAllocation = () => {
    // Simplified optimal allocation algorithm
    const allocation = tasks.map(task => {
      const suitableResources = resources.filter(resource => 
        task.requiredSkills.some(skill => resource.skills.includes(skill))
      );
      
      if (suitableResources.length === 0) return { task, resource: null, efficiency: 0 };
      
      // Select resource with best skill/cost ratio
      const bestResource = suitableResources.reduce((best, current) => {
        const currentSkillMatch = task.requiredSkills.filter(skill => current.skills.includes(skill)).length;
        const bestSkillMatch = task.requiredSkills.filter(skill => best.skills.includes(skill)).length;
        const currentEfficiency = currentSkillMatch / current.hourlyRate;
        const bestEfficiency = bestSkillMatch / best.hourlyRate;
        
        return currentEfficiency > bestEfficiency ? current : best;
      });
      
      const skillMatch = task.requiredSkills.filter(skill => bestResource.skills.includes(skill)).length;
      const efficiency = (skillMatch / task.requiredSkills.length) * 100;
      
      return { task, resource: bestResource, efficiency };
    });
    
    return allocation;
  };

  const tabs = [
    { id: 'data-input', name: 'Saisie des Données', icon: '📝' },
    { id: 'resource-leveling', name: 'Allocation Optimale', icon: '📊' },
    { id: 'scenario-analysis', name: 'Analyse de Scénarios', icon: '🎯' }
  ];

  const allocation = calculateOptimalAllocation();
  const totalCost = allocation.reduce((sum, item) => {
    if (item.resource) {
      return sum + (item.resource.hourlyRate * item.task.duration * 8);
    }
    return sum;
  }, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <Link href="/" className="inline-flex items-center px-4 py-2 bg-white/80 backdrop-blur-sm text-gray-700 rounded-xl hover:bg-white/90 transition-all duration-200 shadow-sm border border-gray-200/50">
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
                Retour à l'Accueil
              </Link>
            </div>
          </div>
          
          <div className="text-center">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-blue-800 bg-clip-text text-transparent mb-4">
              Allocation des Ressources
            </h1>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              Optimisez l'allocation des ressources avec des algorithmes avancés et l'analyse de scénarios
            </p>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex justify-center mb-8">
          <div className="inline-flex bg-white/60 backdrop-blur-sm rounded-2xl p-2 border border-gray-200/50 shadow-sm">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-6 py-3 rounded-xl font-medium transition-all duration-200 ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg transform scale-105'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-white/80'
                }`}
              >
                <span className="text-lg">{tab.icon}</span>
                <span>{tab.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl border border-gray-200/50 overflow-hidden">
          <div className="p-8">
            {activeTab === 'data-input' && (
              <div className="animate-fadeIn">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Add Resources */}
                  <div>
                    <div className="flex items-center space-x-3 mb-6">
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
                        <span className="text-white text-lg">👥</span>
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-900">Ajouter des Ressources</h3>
                        <p className="text-gray-600 text-sm">Définissez votre équipe et leurs compétences</p>
                      </div>
                    </div>
                    
                    <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-6 border border-blue-200/50 mb-6">
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Nom</label>
                          <input
                            type="text"
                            value={newResource.name}
                            onChange={(e) => setNewResource({...newResource, name: e.target.value})}
                            className="w-full px-4 py-3 bg-white/80 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                            placeholder="Ex: Jean Dupont"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Type</label>
                          <select
                            value={newResource.type}
                            onChange={(e) => setNewResource({...newResource, type: e.target.value as Resource['type']})}
                            className="w-full px-4 py-3 bg-white/80 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                          >
                            <option value="developer">Développeur</option>
                            <option value="designer">Designer</option>
                            <option value="tester">Testeur</option>
                            <option value="manager">Manager</option>
                          </select>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Tarif/h (€)</label>
                            <input
                              type="number"
                              value={newResource.hourlyRate}
                              onChange={(e) => setNewResource({...newResource, hourlyRate: Number(e.target.value)})}
                              className="w-full px-4 py-3 bg-white/80 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                              placeholder="75"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Disponibilité/j (h)</label>
                            <input
                              type="number"
                              value={newResource.availability}
                              onChange={(e) => setNewResource({...newResource, availability: Number(e.target.value)})}
                              className="w-full px-4 py-3 bg-white/80 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                              placeholder="8"
                            />
                          </div>
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Compétences (séparées par des virgules)</label>
                          <input
                            type="text"
                            value={newResource.skills}
                            onChange={(e) => setNewResource({...newResource, skills: e.target.value})}
                            className="w-full px-4 py-3 bg-white/80 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                            placeholder="React, Node.js, TypeScript"
                          />
                        </div>
                        
                        <button
                          onClick={addResource}
                          className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 px-6 rounded-xl font-medium hover:shadow-lg transform hover:scale-105 transition-all duration-200"
                        >
                          Ajouter la Ressource
                        </button>
                      </div>
                    </div>
                    
                    {/* Resources List */}
                    <div className="space-y-3">
                      <h4 className="font-bold text-gray-900">Ressources Actuelles ({resources.length})</h4>
                      {resources.map((resource) => (
                        <div key={resource.id} className="bg-white/80 rounded-xl p-4 border border-gray-200/50 flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className={`w-8 h-8 bg-gradient-to-br ${getResourceTypeColor(resource.type)} rounded-lg flex items-center justify-center text-white text-sm`}>
                              {getResourceTypeIcon(resource.type)}
                            </div>
                            <div>
                              <div className="font-medium text-gray-900">{resource.name}</div>
                              <div className="text-sm text-gray-600">{resource.hourlyRate}€/h • {resource.skills.join(', ')}</div>
                            </div>
                          </div>
                          <button
                            onClick={() => removeResource(resource.id)}
                            className="text-red-500 hover:text-red-700 p-2 rounded-lg hover:bg-red-50 transition-all duration-200"
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Add Tasks */}
                  <div>
                    <div className="flex items-center space-x-3 mb-6">
                      <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-teal-600 rounded-xl flex items-center justify-center">
                        <span className="text-white text-lg">📋</span>
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-900">Ajouter des Tâches</h3>
                        <p className="text-gray-600 text-sm">Définissez les tâches de votre projet</p>
                      </div>
                    </div>
                    
                    <div className="bg-gradient-to-br from-green-50 to-teal-50 rounded-2xl p-6 border border-green-200/50 mb-6">
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Nom de la tâche</label>
                          <input
                            type="text"
                            value={newTask.name}
                            onChange={(e) => setNewTask({...newTask, name: e.target.value})}
                            className="w-full px-4 py-3 bg-white/80 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
                            placeholder="Ex: Développement Frontend"
                          />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Durée (jours)</label>
                            <input
                              type="number"
                              value={newTask.duration}
                              onChange={(e) => setNewTask({...newTask, duration: Number(e.target.value)})}
                              className="w-full px-4 py-3 bg-white/80 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
                              placeholder="15"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Priorité</label>
                            <select
                              value={newTask.priority}
                              onChange={(e) => setNewTask({...newTask, priority: Number(e.target.value)})}
                              className="w-full px-4 py-3 bg-white/80 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
                            >
                              <option value={1}>Haute (1)</option>
                              <option value={2}>Moyenne (2)</option>
                              <option value={3}>Basse (3)</option>
                            </select>
                          </div>
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Compétences requises (séparées par des virgules)</label>
                          <input
                            type="text"
                            value={newTask.requiredSkills}
                            onChange={(e) => setNewTask({...newTask, requiredSkills: e.target.value})}
                            className="w-full px-4 py-3 bg-white/80 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
                            placeholder="React, TypeScript"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Effort requis (heures)</label>
                          <input
                            type="number"
                            value={newTask.resourceRequirement}
                            onChange={(e) => setNewTask({...newTask, resourceRequirement: Number(e.target.value)})}
                            className="w-full px-4 py-3 bg-white/80 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
                            placeholder="120"
                          />
                        </div>
                        
                        <button
                          onClick={addTask}
                          className="w-full bg-gradient-to-r from-green-500 to-teal-600 text-white py-3 px-6 rounded-xl font-medium hover:shadow-lg transform hover:scale-105 transition-all duration-200"
                        >
                          Ajouter la Tâche
                        </button>
                      </div>
                    </div>
                    
                    {/* Tasks List */}
                    <div className="space-y-3">
                      <h4 className="font-bold text-gray-900">Tâches Actuelles ({tasks.length})</h4>
                      {tasks.map((task) => (
                        <div key={task.id} className="bg-white/80 rounded-xl p-4 border border-gray-200/50 flex items-center justify-between">
                          <div>
                            <div className="font-medium text-gray-900">{task.name}</div>
                            <div className="text-sm text-gray-600">
                              {task.duration} jours • Priorité {task.priority} • {task.requiredSkills.join(', ')}
                            </div>
                          </div>
                          <button
                            onClick={() => removeTask(task.id)}
                            className="text-red-500 hover:text-red-700 p-2 rounded-lg hover:bg-red-50 transition-all duration-200"
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'resource-leveling' && (
              <div className="animate-fadeIn">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Resources */}
                  <div>
                    <div className="flex items-center space-x-3 mb-6">
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
                        <span className="text-white text-lg">👥</span>
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-900">Ressources Disponibles</h3>
                        <p className="text-gray-600 text-sm">Membres de l'équipe et leurs compétences</p>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      {resources.map((resource) => (
                        <div key={resource.id} className="bg-gradient-to-br from-gray-50 to-blue-50 rounded-2xl p-6 border border-gray-200/50">
                          <div className="flex items-start justify-between mb-4">
                            <div className="flex items-center space-x-3">
                              <div className={`w-12 h-12 bg-gradient-to-br ${getResourceTypeColor(resource.type)} rounded-xl flex items-center justify-center text-white text-xl`}>
                                {getResourceTypeIcon(resource.type)}
                              </div>
                              <div>
                                <h4 className="font-bold text-gray-900">{resource.name}</h4>
                                <p className="text-sm text-gray-600 capitalize">{resource.type}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-lg font-bold text-gray-900">{resource.hourlyRate}€/h</div>
                              <div className="text-sm text-gray-600">{resource.availability}h/jour</div>
                            </div>
                          </div>
                          
                          <div>
                            <p className="text-sm font-medium text-gray-700 mb-2">Compétences:</p>
                            <div className="flex flex-wrap gap-2">
                              {resource.skills.map((skill, index) => (
                                <span key={index} className="px-3 py-1 bg-white/80 text-gray-700 text-xs font-medium rounded-full border border-gray-200">
                                  {skill}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Tasks & Allocation */}
                  <div>
                    <div className="flex items-center space-x-3 mb-6">
                      <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-teal-600 rounded-xl flex items-center justify-center">
                        <span className="text-white text-lg">📋</span>
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-900">Allocation Optimale</h3>
                        <p className="text-gray-600 text-sm">Attribution automatique par IA</p>
                      </div>
                    </div>
                    
                    <div className="space-y-4 mb-6">
                      {allocation.map((item, index) => (
                        <div key={index} className="bg-gradient-to-br from-green-50 to-teal-50 rounded-2xl p-6 border border-green-200/50">
                          <div className="flex items-start justify-between mb-4">
                            <div>
                              <h4 className="font-bold text-gray-900 mb-1">{item.task.name}</h4>
                              <div className="flex items-center space-x-2 mb-2">
                                <span className={`px-2 py-1 text-xs font-medium rounded-full border ${getPriorityColor(item.task.priority)}`}>
                                  Priorité {item.task.priority}
                                </span>
                                <span className="text-sm text-gray-600">{item.task.duration} jours</span>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-lg font-bold text-green-600">{item.efficiency.toFixed(0)}%</div>
                              <div className="text-sm text-gray-600">Efficacité</div>
                            </div>
                          </div>
                          
                          {item.resource ? (
                            <div className="flex items-center justify-between bg-white/80 rounded-xl p-4">
                              <div className="flex items-center space-x-3">
                                <div className={`w-8 h-8 bg-gradient-to-br ${getResourceTypeColor(item.resource.type)} rounded-lg flex items-center justify-center text-white text-sm`}>
                                  {getResourceTypeIcon(item.resource.type)}
                                </div>
                                <div>
                                  <div className="font-medium text-gray-900">{item.resource.name}</div>
                                  <div className="text-sm text-gray-600">{item.resource.hourlyRate}€/h</div>
                                </div>
                              </div>
                              <div className="text-right">
                                <div className="font-bold text-gray-900">{(item.resource.hourlyRate * item.task.duration * 8).toLocaleString()}€</div>
                                <div className="text-sm text-gray-600">Coût Total</div>
                              </div>
                            </div>
                          ) : (
                            <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-center">
                              <span className="text-red-600 font-medium">Aucune ressource adaptée trouvée</span>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                    
                    {/* Summary */}
                    <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-6 border border-blue-200/50">
                      <h4 className="text-xl font-bold text-gray-900 mb-4">Résumé du Projet</h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="text-center p-4 bg-white/80 rounded-xl">
                          <div className="text-2xl font-bold text-blue-600">{totalCost.toLocaleString()}€</div>
                          <div className="text-sm text-gray-600">Coût Total</div>
                        </div>
                        <div className="text-center p-4 bg-white/80 rounded-xl">
                          <div className="text-2xl font-bold text-purple-600">{Math.max(...tasks.map(t => t.duration))}</div>
                          <div className="text-sm text-gray-600">Jours</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'scenario-analysis' && (
              <div className="animate-fadeIn">
                <div className="flex items-center space-x-3 mb-8">
                  <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center">
                    <span className="text-white text-lg">🎯</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900">Analyse de Scénarios</h3>
                    <p className="text-gray-600 text-sm">Comparez différentes approches de projet</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {scenarios.map((scenario, index) => (
                    <div key={index} className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-6 border border-purple-200/50 hover:shadow-lg transition-all duration-200">
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="text-xl font-bold text-gray-900">{scenario.name}</h4>
                        <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                          <span className="text-white text-lg">
                            {index === 0 ? '⚡' : index === 1 ? '⚖️' : '💰'}
                          </span>
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-gray-700">Budget:</span>
                          <span className="font-bold text-gray-900">{scenario.budget.toLocaleString()}€</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-gray-700">Délai:</span>
                          <span className="font-bold text-gray-900">{scenario.timeline} jours</span>
                        </div>
                        
                        <div className="pt-3 border-t border-gray-200">
                          <p className="text-xs font-medium text-gray-700 mb-2">Pondération:</p>
                          <div className="space-y-2">
                            <div className="flex justify-between text-xs">
                              <span>Qualité:</span>
                              <span className="font-medium">{Math.round(scenario.qualityWeight * 100)}%</span>
                            </div>
                            <div className="flex justify-between text-xs">
                              <span>Coût:</span>
                              <span className="font-medium">{Math.round(scenario.costWeight * 100)}%</span>
                            </div>
                            <div className="flex justify-between text-xs">
                              <span>Temps:</span>
                              <span className="font-medium">{Math.round(scenario.timeWeight * 100)}%</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}