export interface SensitivityInput {
  baseValue: number;
  variableRange: number;
  impactFactor: number;
}

export interface MonteCarloInput {
  iterations: number;
  variables: {
    name: string;
    min: number;
    max: number;
    distribution: 'uniform' | 'normal';
  }[];
}

export interface MonteCarloResults {
  results: number[];
  mean: number;
  median: number;
  p5: number;
  p95: number;
  std: number;
}

export interface DecisionNode {
  id: string;
  name: string;
  type: 'decision' | 'chance' | 'outcome';
  value?: number;
  probability?: number;
  children?: DecisionNode[];
}

export interface RiskItem {
  id: string;
  name: string;
  description: string;
  probability: number;
  impact: number;
  category: string;
  mitigation: string;
  status: 'open' | 'mitigated' | 'closed';
}