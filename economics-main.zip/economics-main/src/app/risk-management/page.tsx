'use client';

import { useState } from 'react';
import Link from 'next/link';
import { SensitivityInput, MonteCarloInput, MonteCarloResults } from './types';
import SensitivityAnalysis from './components/SensitivityAnalysis';
import MonteCarloSimulation from './components/MonteCarloSimulation';

export default function RiskManagement() {
  const [activeTab, setActiveTab] = useState('sensitivity');
  const [sensitivityInputs, setSensitivityInputs] = useState<SensitivityInput>({
    baseValue: 100000,
    variableRange: 20,
    impactFactor: 1.5
  });
  const [monteCarloInputs, setMonteCarloInputs] = useState<MonteCarloInput>({
    iterations: 1000,
    variables: [
      { name: 'Development Cost', min: 80000, max: 120000, distribution: 'normal' },
      { name: 'Timeline (months)', min: 8, max: 15, distribution: 'uniform' },
      { name: 'Team Size', min: 5, max: 12, distribution: 'normal' }
    ]
  });
  const [monteCarloResults, setMonteCarloResults] = useState<MonteCarloResults | null>(null);

  const tabs = [
    { id: 'sensitivity', name: 'Sensitivity Analysis', icon: '📊' },
    { id: 'monte-carlo', name: 'Monte Carlo Simulation', icon: '🎲' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-red-50 to-pink-100">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <Link href="/" className="inline-flex items-center px-4 py-2 bg-white/80 backdrop-blur-sm text-gray-700 rounded-xl hover:bg-white/90 transition-all duration-200 shadow-sm border border-gray-200/50">
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
                Back to Home
              </Link>
            </div>
          </div>
          
          <div className="text-center">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-red-600 via-pink-600 to-red-800 bg-clip-text text-transparent mb-4">
              Risk Management
            </h1>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              Advanced risk analysis with sensitivity analysis and Monte Carlo simulations
            </p>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex justify-center mb-8">
          <div className="inline-flex bg-white/60 backdrop-blur-sm rounded-2xl p-2 border border-gray-200/50 shadow-sm">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-6 py-3 rounded-xl font-medium transition-all duration-200 ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-red-500 to-pink-600 text-white shadow-lg transform scale-105'
                    : 'text-gray-600 hover:text-red-600 hover:bg-white/50'
                }`}
              >
                <span className="text-lg">{tab.icon}</span>
                <span>{tab.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl border border-white/20 overflow-hidden">
          <div className="p-8">
            {activeTab === 'sensitivity' && (
              <div className="animate-fadeIn">
                <div className="flex items-center space-x-3 mb-8">
                  <div className="w-10 h-10 bg-gradient-to-br from-red-500 to-pink-600 rounded-xl flex items-center justify-center">
                    <span className="text-white text-lg">📊</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900">Sensitivity Analysis</h3>
                    <p className="text-gray-600 text-sm">Analyze how changes in variables affect project outcomes</p>
                  </div>
                </div>
                <SensitivityAnalysis 
                  inputs={sensitivityInputs}
                  onInputsChange={setSensitivityInputs}
                />
              </div>
            )}

            {activeTab === 'monte-carlo' && (
              <div className="animate-fadeIn">
                <div className="flex items-center space-x-3 mb-8">
                  <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center">
                    <span className="text-white text-lg">🎲</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900">Monte Carlo Simulation</h3>
                    <p className="text-gray-600 text-sm">Statistical risk analysis through probabilistic modeling</p>
                  </div>
                </div>
                <MonteCarloSimulation
                  inputs={monteCarloInputs}
                  onInputsChange={setMonteCarloInputs}
                  results={monteCarloResults}
                  onRunSimulation={setMonteCarloResults}
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}