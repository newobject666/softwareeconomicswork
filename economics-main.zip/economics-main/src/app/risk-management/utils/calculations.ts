import { SensitivityInput, MonteCarloInput, MonteCarloResults } from '../types';

export const performSensitivityAnalysis = (inputs: SensitivityInput) => {
  const { baseValue, variableRange, impactFactor } = inputs;
  const scenarios = [];
  
  for (let i = -variableRange; i <= variableRange; i += 5) {
    const variableChange = i;
    const newValue = baseValue * (1 + variableChange / 100);
    const impact = (newValue - baseValue) * impactFactor;
    scenarios.push({
      variableChange,
      newValue,
      impact,
      totalValue: baseValue + impact
    });
  }
  
  return scenarios;
};

export const runMonteCarloSimulation = (inputs: MonteCarloInput): MonteCarloResults => {
  const results = [];
  
  for (let i = 0; i < inputs.iterations; i++) {
    let totalCost = 0;
    
    inputs.variables.forEach(variable => {
      let value;
      if (variable.distribution === 'uniform') {
        value = Math.random() * (variable.max - variable.min) + variable.min;
      } else {
        const mean = (variable.max + variable.min) / 2;
        const std = (variable.max - variable.min) / 6;
        value = mean + (Math.random() - 0.5) * 2 * std;
        value = Math.max(variable.min, Math.min(variable.max, value));
      }
      totalCost += value;
    });
    
    results.push(totalCost);
  }
  
  results.sort((a, b) => a - b);
  const mean = results.reduce((sum, val) => sum + val, 0) / results.length;
  const median = results[Math.floor(results.length / 2)];
  const p5 = results[Math.floor(results.length * 0.05)];
  const p95 = results[Math.floor(results.length * 0.95)];
  const std = Math.sqrt(results.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / results.length);
  
  return { results, mean, median, p5, p95, std };
};