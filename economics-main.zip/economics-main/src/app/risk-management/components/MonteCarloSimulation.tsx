import { MonteCarloInput, MonteCarloResults } from '../types';
import { runMonteCarloSimulation } from '../utils/calculations';

interface Props {
  inputs: MonteCarloInput;
  onInputsChange: (inputs: MonteCarloInput) => void;
  results: MonteCarloResults | null;
  onRunSimulation: (results: MonteCarloResults) => void;
}

export default function MonteCarloSimulation({ inputs, onInputsChange, results, onRunSimulation }: Props) {
  const handleRunSimulation = () => {
    const simulationResults = runMonteCarloSimulation(inputs);
    onRunSimulation(simulationResults);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <h3 className="text-xl font-semibold mb-4">Simulation Parameters</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Number of Iterations
              </label>
              <input
                type="number"
                value={inputs.iterations}
                onChange={(e) => onInputsChange({
                  ...inputs,
                  iterations: parseInt(e.target.value) || 1000
                })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
              />
            </div>
            
            <button
              onClick={handleRunSimulation}
              className="w-full bg-red-600 text-white py-2 px-4 rounded-lg hover:bg-red-700 transition-colors"
            >
              Run Simulation
            </button>
            
            {inputs.variables.map((variable, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-4">
                <h4 className="font-medium mb-2">{variable.name}</h4>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs text-gray-600">Min Value</label>
                    <input
                      type="number"
                      value={variable.min}
                      onChange={(e) => {
                        const newVariables = [...inputs.variables];
                        newVariables[index].min = parseFloat(e.target.value) || 0;
                        onInputsChange({ ...inputs, variables: newVariables });
                      }}
                      className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-red-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-600">Max Value</label>
                    <input
                      type="number"
                      value={variable.max}
                      onChange={(e) => {
                        const newVariables = [...inputs.variables];
                        newVariables[index].max = parseFloat(e.target.value) || 0;
                        onInputsChange({ ...inputs, variables: newVariables });
                      }}
                      className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-red-500"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div>
          <h3 className="text-xl font-semibold mb-4">Simulation Results</h3>
          {results ? (
            <div className="bg-gray-50 p-4 rounded-lg space-y-3">
              <div className="flex justify-between">
                <span className="font-medium">Mean:</span>
                <span>${results.mean.toFixed(0)}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Median:</span>
                <span>${results.median.toFixed(0)}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Standard Deviation:</span>
                <span>${results.std.toFixed(0)}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">5th Percentile:</span>
                <span className="text-green-600">${results.p5.toFixed(0)}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">95th Percentile:</span>
                <span className="text-red-600">${results.p95.toFixed(0)}</span>
              </div>
              <div className="mt-4 p-3 bg-blue-50 rounded">
                <div className="text-sm font-medium text-blue-800">Risk Assessment</div>
                <div className="text-xs text-blue-600">
                  90% confidence interval: ${results.p5.toFixed(0)} - ${results.p95.toFixed(0)}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-gray-50 p-4 rounded-lg text-center text-gray-500">
              Click "Run Simulation" to see results
            </div>
          )}
        </div>
      </div>
    </div>
  );
}