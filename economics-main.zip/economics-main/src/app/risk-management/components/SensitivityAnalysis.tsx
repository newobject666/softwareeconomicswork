import React from 'react';
import { SensitivityInput } from '../types';
import { performSensitivityAnalysis } from '../utils/calculations';

interface Props {
  inputs: SensitivityInput;
  onInputsChange: (inputs: SensitivityInput) => void;
}

export default function SensitivityAnalysis({ inputs, onInputsChange }: Props) {
  const results = performSensitivityAnalysis(inputs);

  return (
    <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
      {/* Section des paramètres */}
      <div className="space-y-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
            <span className="text-white text-lg">📊</span>
          </div>
          <div>
            <h3 className="text-xl font-bold text-gray-900">Paramètres d'Analyse</h3>
            <p className="text-gray-600 text-sm">Configurez les variables pour l'analyse</p>
          </div>
        </div>
        
        <div className="space-y-6">
          <div className="group">
            <label className="block text-sm font-semibold text-gray-700 mb-3 flex items-center space-x-2">
              <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
              <span>Valeur de Base ($)</span>
            </label>
            <div className="relative">
              <input
                type="number"
                value={inputs.baseValue}
                onChange={(e) => onInputsChange({...inputs, baseValue: Number(e.target.value)})}
                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 group-hover:bg-white"
                placeholder="Entrez la valeur de base"
              />
              <div className="absolute inset-y-0 right-0 flex items-center pr-4">
                <span className="text-gray-400 text-sm">USD</span>
              </div>
            </div>
          </div>
          
          <div className="group">
            <label className="block text-sm font-semibold text-gray-700 mb-3 flex items-center space-x-2">
              <span className="w-2 h-2 bg-green-500 rounded-full"></span>
              <span>Plage de Variation (±%)</span>
            </label>
            <input
              type="number"
              value={inputs.variableRange}
              onChange={(e) => onInputsChange({...inputs, variableRange: Number(e.target.value)})}
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 group-hover:bg-white"
              placeholder="Pourcentage de variation"
            />
          </div>
          
          <div className="group">
            <label className="block text-sm font-semibold text-gray-700 mb-3 flex items-center space-x-2">
              <span className="w-2 h-2 bg-purple-500 rounded-full"></span>
              <span>Facteur d'Impact</span>
            </label>
            <input
              type="number"
              step="0.1"
              value={inputs.impactFactor}
              onChange={(e) => onInputsChange({...inputs, impactFactor: Number(e.target.value)})}
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 group-hover:bg-white"
              placeholder="Facteur multiplicateur"
            />
          </div>
        </div>
      </div>
      
      {/* Section des résultats */}
      <div className="space-y-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-teal-600 rounded-xl flex items-center justify-center">
            <span className="text-white text-lg">📈</span>
          </div>
          <div>
            <h3 className="text-xl font-bold text-gray-900">Résultats de l'Analyse</h3>
            <p className="text-gray-600 text-sm">Impact des variations sur la valeur</p>
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-gray-50 to-blue-50 rounded-2xl p-6 border border-gray-200/50">
          <div className="overflow-hidden rounded-xl bg-white shadow-sm">
            <table className="w-full">
              <thead className="bg-gradient-to-r from-gray-50 to-blue-50">
                <tr>
                  <th className="text-left py-4 px-4 font-semibold text-gray-700">Variation (%)</th>
                  <th className="text-left py-4 px-4 font-semibold text-gray-700">Nouvelle Valeur</th>
                  <th className="text-left py-4 px-4 font-semibold text-gray-700">Impact</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {results.map((result, index) => (
                  <tr key={index} className="hover:bg-gray-50/50 transition-colors">
                    <td className="py-3 px-4 font-medium">
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        result.variableChange > 0 
                          ? 'bg-red-100 text-red-700' 
                          : result.variableChange < 0 
                          ? 'bg-green-100 text-green-700'
                          : 'bg-gray-100 text-gray-700'
                      }`}>
                        {result.variableChange > 0 ? '+' : ''}{result.variableChange}%
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono text-sm">
                      ${result.newValue.toLocaleString()}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-semibold ${
                        result.impact >= 0 
                          ? 'bg-green-100 text-green-700' 
                          : 'bg-red-100 text-red-700'
                      }`}>
                        {result.impact >= 0 ? '+' : ''}${result.impact.toLocaleString()}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}