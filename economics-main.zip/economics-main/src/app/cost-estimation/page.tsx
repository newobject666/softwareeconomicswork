'use client';

import { useState } from 'react';
import Link from 'next/link';

interface CocomoInputs {
  kloc: number;
  mode: 'organic' | 'semi-detached' | 'embedded';
  effortAdjustmentFactor: number;
}

interface FunctionPointInputs {
  externalInputs: number;
  externalOutputs: number;
  externalInquiries: number;
  internalFiles: number;
  externalInterfaces: number;
  complexityFactor: number;
  languageFactor: number;
}

export default function CostEstimation() {
  const [activeTab, setActiveTab] = useState('cocomo');
  const [cocomoInputs, setCocomoInputs] = useState<CocomoInputs>({
    kloc: 10,
    mode: 'organic',
    effortAdjustmentFactor: 1.0
  });
  
  const [fpInputs, setFpInputs] = useState<FunctionPointInputs>({
    externalInputs: 10,
    externalOutputs: 5,
    externalInquiries: 3,
    internalFiles: 8,
    externalInterfaces: 2,
    complexityFactor: 1.0,
    languageFactor: 50
  });

  const calculateCocomo = () => {
    const { kloc, mode, effortAdjustmentFactor } = cocomoInputs;
    
    const coefficients = {
      organic: { a: 2.4, b: 1.05, c: 2.5, d: 0.38 },
      'semi-detached': { a: 3.0, b: 1.12, c: 2.5, d: 0.35 },
      embedded: { a: 3.6, b: 1.20, c: 2.5, d: 0.32 }
    };
    
    const coeff = coefficients[mode];
    const effort = coeff.a * Math.pow(kloc, coeff.b) * effortAdjustmentFactor;
    const duration = coeff.c * Math.pow(effort, coeff.d);
    const teamSize = effort / duration;
    const cost = effort * 8000; // Assuming $8000 per person-month
    
    return { effort, duration, teamSize, cost };
  };

  const calculateFunctionPoints = () => {
    const { externalInputs, externalOutputs, externalInquiries, internalFiles, externalInterfaces, complexityFactor, languageFactor } = fpInputs;
    
    // Simplified function point calculation
    const weights = {
      externalInputs: 4,
      externalOutputs: 5,
      externalInquiries: 4,
      internalFiles: 10,
      externalInterfaces: 7
    };
    
    const unadjustedFP = (
      externalInputs * weights.externalInputs +
      externalOutputs * weights.externalOutputs +
      externalInquiries * weights.externalInquiries +
      internalFiles * weights.internalFiles +
      externalInterfaces * weights.externalInterfaces
    );
    
    const adjustedFP = unadjustedFP * complexityFactor;
    const estimatedLOC = adjustedFP * languageFactor;
    const effort = adjustedFP * 0.04; // Simplified effort calculation
    
    return { unadjustedFP, adjustedFP, estimatedLOC, effort };
  };

  const cocomoResults = calculateCocomo();
  const fpResults = calculateFunctionPoints();

  const tabs = [
    { id: 'cocomo', label: 'COCOMO', icon: '📊' },
    { id: 'function-points', label: 'Function Points', icon: '🔢' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-cyan-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <Link href="/" className="inline-flex items-center px-4 py-2 bg-white/80 backdrop-blur-sm border border-gray-200 rounded-xl text-gray-700 hover:bg-gray-50 transition-all duration-200 shadow-sm hover:shadow-md">
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
                Back to Home
              </Link>
            </div>
          </div>
          
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-2xl mb-6 shadow-lg">
              <span className="text-white text-2xl">💰</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Cost Estimation</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Estimate project costs using proven methodologies like COCOMO and Function Points
            </p>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex justify-center mb-8">
          <div className="inline-flex bg-white/80 backdrop-blur-sm rounded-2xl p-2 shadow-lg border border-gray-200/50">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-6 py-3 rounded-xl font-medium transition-all duration-200 ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-blue-500 to-cyan-500 text-white shadow-md'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                }`}
              >
                <span className="text-lg">{tab.icon}</span>
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="max-w-6xl mx-auto">
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl border border-gray-200/50 overflow-hidden">
            {activeTab === 'cocomo' && (
              <div className="p-8 animate-fadeIn">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* COCOMO Inputs */}
                  <div className="space-y-6">
                    <div className="flex items-center space-x-3 mb-6">
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-xl flex items-center justify-center">
                        <span className="text-white text-lg">⚙️</span>
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-900">COCOMO Parameters</h3>
                        <p className="text-gray-600 text-sm">Configure your project parameters</p>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Lines of Code (KLOC)
                        </label>
                        <input
                          type="number"
                          value={cocomoInputs.kloc}
                          onChange={(e) => setCocomoInputs({ ...cocomoInputs, kloc: parseFloat(e.target.value) || 0 })}
                          className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                          placeholder="Enter KLOC"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Development Mode
                        </label>
                        <select
                          value={cocomoInputs.mode}
                          onChange={(e) => setCocomoInputs({ ...cocomoInputs, mode: e.target.value as 'organic' | 'semi-detached' | 'embedded' })}
                          className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                        >
                          <option value="organic">Organic</option>
                          <option value="semi-detached">Semi-detached</option>
                          <option value="embedded">Embedded</option>
                        </select>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Effort Adjustment Factor
                        </label>
                        <input
                          type="number"
                          step="0.1"
                          value={cocomoInputs.effortAdjustmentFactor}
                          onChange={(e) => setCocomoInputs({ ...cocomoInputs, effortAdjustmentFactor: parseFloat(e.target.value) || 1.0 })}
                          className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                          placeholder="1.0"
                        />
                      </div>
                    </div>
                  </div>

                  {/* COCOMO Results */}
                  <div className="space-y-6">
                    <div className="flex items-center space-x-3 mb-6">
                      <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-teal-600 rounded-xl flex items-center justify-center">
                        <span className="text-white text-lg">📊</span>
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-900">COCOMO Results</h3>
                        <p className="text-gray-600 text-sm">Calculated metrics</p>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl p-6 border border-blue-200/50">
                        <div className="text-2xl font-bold text-blue-600 mb-2">
                          {cocomoResults.effort.toFixed(1)}
                        </div>
                        <div className="text-sm font-medium text-gray-700">Effort (Person-Months)</div>
                      </div>
                      
                      <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-6 border border-green-200/50">
                        <div className="text-2xl font-bold text-green-600 mb-2">
                          {cocomoResults.duration.toFixed(1)}
                        </div>
                        <div className="text-sm font-medium text-gray-700">Duration (Months)</div>
                      </div>
                      
                      <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-6 border border-purple-200/50">
                        <div className="text-2xl font-bold text-purple-600 mb-2">
                          {cocomoResults.teamSize.toFixed(1)}
                        </div>
                        <div className="text-sm font-medium text-gray-700">Team Size (People)</div>
                      </div>
                      
                      <div className="bg-gradient-to-br from-orange-50 to-red-50 rounded-2xl p-6 border border-orange-200/50">
                        <div className="text-2xl font-bold text-orange-600 mb-2">
                          ${cocomoResults.cost.toLocaleString()}
                        </div>
                        <div className="text-sm font-medium text-gray-700">Estimated Cost</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'function-points' && (
              <div className="p-8 animate-fadeIn">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Function Points Inputs */}
                  <div className="space-y-6">
                    <div className="flex items-center space-x-3 mb-6">
                      <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center">
                        <span className="text-white text-lg">🔢</span>
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-900">Function Point Parameters</h3>
                        <p className="text-gray-600 text-sm">Define system components</p>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          External Inputs
                        </label>
                        <input
                          type="number"
                          value={fpInputs.externalInputs}
                          onChange={(e) => setFpInputs({ ...fpInputs, externalInputs: parseInt(e.target.value) || 0 })}
                          className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          External Outputs
                        </label>
                        <input
                          type="number"
                          value={fpInputs.externalOutputs}
                          onChange={(e) => setFpInputs({ ...fpInputs, externalOutputs: parseInt(e.target.value) || 0 })}
                          className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          External Inquiries
                        </label>
                        <input
                          type="number"
                          value={fpInputs.externalInquiries}
                          onChange={(e) => setFpInputs({ ...fpInputs, externalInquiries: parseInt(e.target.value) || 0 })}
                          className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Internal Files
                        </label>
                        <input
                          type="number"
                          value={fpInputs.internalFiles}
                          onChange={(e) => setFpInputs({ ...fpInputs, internalFiles: parseInt(e.target.value) || 0 })}
                          className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          External Interfaces
                        </label>
                        <input
                          type="number"
                          value={fpInputs.externalInterfaces}
                          onChange={(e) => setFpInputs({ ...fpInputs, externalInterfaces: parseInt(e.target.value) || 0 })}
                          className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Complexity Factor
                        </label>
                        <input
                          type="number"
                          step="0.1"
                          value={fpInputs.complexityFactor}
                          onChange={(e) => setFpInputs({ ...fpInputs, complexityFactor: parseFloat(e.target.value) || 1.0 })}
                          className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Language Factor (LOC/FP)
                        </label>
                        <input
                          type="number"
                          value={fpInputs.languageFactor}
                          onChange={(e) => setFpInputs({ ...fpInputs, languageFactor: parseInt(e.target.value) || 50 })}
                          className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Function Points Results */}
                  <div className="space-y-6">
                    <div className="flex items-center space-x-3 mb-6">
                      <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-teal-600 rounded-xl flex items-center justify-center">
                        <span className="text-white text-lg">📊</span>
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-900">Function Point Results</h3>
                        <p className="text-gray-600 text-sm">Calculated metrics</p>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-6 border border-purple-200/50">
                        <div className="text-2xl font-bold text-purple-600 mb-2">
                          {fpResults.unadjustedFP.toFixed(0)}
                        </div>
                        <div className="text-sm font-medium text-gray-700">Unadjusted Function Points</div>
                      </div>
                      
                      <div className="bg-gradient-to-br from-pink-50 to-rose-50 rounded-2xl p-6 border border-pink-200/50">
                        <div className="text-2xl font-bold text-pink-600 mb-2">
                          {fpResults.adjustedFP.toFixed(0)}
                        </div>
                        <div className="text-sm font-medium text-gray-700">Adjusted Function Points</div>
                      </div>
                      
                      <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl p-6 border border-blue-200/50">
                        <div className="text-2xl font-bold text-blue-600 mb-2">
                          {fpResults.estimatedLOC.toLocaleString()}
                        </div>
                        <div className="text-sm font-medium text-gray-700">Estimated Lines of Code</div>
                      </div>
                      
                      <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-6 border border-green-200/50">
                        <div className="text-2xl font-bold text-green-600 mb-2">
                          {fpResults.effort.toFixed(1)}
                        </div>
                        <div className="text-sm font-medium text-gray-700">Estimated Effort (PM)</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}