export interface ProjectData {
  id?: number;
  name: string;
  description: string;
  created_at?: Date;
  updated_at?: Date;
  costEstimation?: {
    cocomo?: {
      kloc: number;
      projectType: 'organic' | 'semi-detached' | 'embedded';
      effort: number;
      time: number;
      people: number;
    };
    functionPoints?: {
      inputs: number;
      outputs: number;
      inquiries: number;
      files: number;
      interfaces: number;
      complexity: 'simple' | 'average' | 'complex';
      adjustedFP: number;
    };
  };
  budgeting?: {
    initialInvestment: number;
    annualCashFlows: number[];
    discountRate: number;
    roi: number;
    npv: number;
    irr: number;
    paybackPeriod: number;
  };
  riskManagement?: {
    sensitivityAnalysis?: any;
    monteCarloResults?: any;
    riskRegister?: RiskItem[];
  };
  resourceAllocation?: {
    resources: Resource[];
    tasks: Task[];
    schedule: any[];
  };
}

export interface RiskItem {
  id?: number;
  project_id?: number;
  description: string;
  probability: number;
  impact: number;
  riskScore: number;
  mitigation: string;
  status: 'open' | 'mitigated' | 'closed';
  created_at?: Date;
}

export interface Resource {
  id?: number;
  project_id?: number;
  name: string;
  type: 'developer' | 'designer' | 'tester' | 'manager';
  hourlyRate: number;
  availability: number;
  skills: string[];
  created_at?: Date;
}

export interface Task {
  id?: number;
  project_id?: number;
  name: string;
  duration: number;
  requiredSkills: string[];
  priority: number;
  dependencies: string[];
  resourceRequirement: number;
  created_at?: Date;
}