import mysql from 'mysql2/promise';

// Vérifier si on a MYSQL_URL ou les paramètres individuels
if (!process.env.MYSQL_URL && (!process.env.MYSQL_HOST || !process.env.MYSQL_USER || !process.env.MYSQL_PASSWORD || !process.env.MYSQL_DATABASE)) {
  throw new Error('Missing MySQL environment variables. Provide either MYSQL_URL or individual MYSQL_* variables');
}

let config: any;

if (process.env.MYSQL_URL) {
  // Utiliser l'URL complète (recommandé pour Railway)
  config = {
    uri: process.env.MYSQL_URL,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
  };
} else {
  // Fallback vers les paramètres individuels
  config = {
    host: process.env.MYSQL_HOST,
    user: process.env.MYSQL_USER,
    password: process.env.MYSQL_PASSWORD,
    database: process.env.MYSQL_DATABASE,
    port: parseInt(process.env.MYSQL_PORT || '3306'),
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
  };
}

let pool: mysql.Pool;

if (process.env.NODE_ENV === 'development') {
  let globalWithMysql = global as typeof globalThis & {
    _mysqlPool?: mysql.Pool;
  };

  if (!globalWithMysql._mysqlPool) {
    globalWithMysql._mysqlPool = mysql.createPool(config);
  }
  pool = globalWithMysql._mysqlPool;
} else {
  pool = mysql.createPool(config);
}

export default pool;