'use client';

import { useEffect, useRef } from 'react';
import * as d3 from 'd3';

interface RiskItem {
  id: string;
  name: string;
  probability: number; // 1-5
  impact: number; // 1-5
  riskScore: number;
}

interface RiskMatrixProps {
  risks: RiskItem[];
  width?: number;
  height?: number;
}

export default function RiskMatrix({ risks, width = 500, height = 400 }: RiskMatrixProps) {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    const margin = { top: 40, right: 40, bottom: 60, left: 60 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    const g = svg.append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // Create scales
    const xScale = d3.scaleLinear()
      .domain([0.5, 5.5])
      .range([0, innerWidth]);

    const yScale = d3.scaleLinear()
      .domain([0.5, 5.5])
      .range([innerHeight, 0]);

    // Create color scale for risk levels
    const colorScale = d3.scaleSequential(d3.interpolateRdYlGn)
      .domain([25, 1]); // Reverse for red=high risk, green=low risk

    // Draw grid
    for (let i = 1; i <= 5; i++) {
      for (let j = 1; j <= 5; j++) {
        const riskLevel = i * j;
        g.append('rect')
          .attr('x', xScale(j - 0.4))
          .attr('y', yScale(i + 0.4))
          .attr('width', xScale(0.8) - xScale(0))
          .attr('height', yScale(0) - yScale(0.8))
          .attr('fill', colorScale(riskLevel))
          .attr('opacity', 0.3)
          .attr('stroke', '#ccc')
          .attr('stroke-width', 1);
      }
    }

    // Add risk items as circles
    g.selectAll('.risk-circle')
      .data(risks)
      .enter()
      .append('circle')
      .attr('class', 'risk-circle')
      .attr('cx', d => xScale(d.impact))
      .attr('cy', d => yScale(d.probability))
      .attr('r', 8)
      .attr('fill', d => colorScale(d.riskScore))
      .attr('stroke', '#333')
      .attr('stroke-width', 2)
      .style('cursor', 'pointer')
      .on('mouseover', function(event, d) {
        // Tooltip
        const tooltip = d3.select('body').append('div')
          .attr('class', 'tooltip')
          .style('position', 'absolute')
          .style('background', 'rgba(0,0,0,0.8)')
          .style('color', 'white')
          .style('padding', '8px')
          .style('border-radius', '4px')
          .style('font-size', '12px')
          .style('pointer-events', 'none')
          .style('opacity', 0);

        tooltip.transition().duration(200).style('opacity', 1);
        tooltip.html(`
          <strong>${d.name}</strong><br/>
          Probability: ${d.probability}<br/>
          Impact: ${d.impact}<br/>
          Risk Score: ${d.riskScore}
        `)
          .style('left', (event.pageX + 10) + 'px')
          .style('top', (event.pageY - 10) + 'px');
      })
      .on('mouseout', function() {
        d3.selectAll('.tooltip').remove();
      });

    // Add axes
    g.append('g')
      .attr('transform', `translate(0,${innerHeight})`)
      .call(d3.axisBottom(xScale).tickValues([1, 2, 3, 4, 5]));

    g.append('g')
      .call(d3.axisLeft(yScale).tickValues([1, 2, 3, 4, 5]));

    // Add axis labels
    g.append('text')
      .attr('transform', 'rotate(-90)')
      .attr('y', 0 - margin.left)
      .attr('x', 0 - (innerHeight / 2))
      .attr('dy', '1em')
      .style('text-anchor', 'middle')
      .style('font-weight', 'bold')
      .text('Probability');

    g.append('text')
      .attr('transform', `translate(${innerWidth / 2}, ${innerHeight + margin.bottom - 10})`)
      .style('text-anchor', 'middle')
      .style('font-weight', 'bold')
      .text('Impact');

    // Add title
    svg.append('text')
      .attr('x', width / 2)
      .attr('y', 20)
      .attr('text-anchor', 'middle')
      .style('font-size', '16px')
      .style('font-weight', 'bold')
      .text('Risk Assessment Matrix');

  }, [risks, width, height]);

  return (
    <div className="risk-matrix-container">
      <svg ref={svgRef} width={width} height={height}></svg>
    </div>
  );
}